var total=200;
var r;
function setup() {
  createCanvas(400, 400);
  r=width/2-16;
}

PVector getVector(int index)
{
  var angle=map(index % total,0,total,0,TWO_PI);
  PVector v=PVector.fromAngle(angle+ PI);
  v.mult(r);
  return v;
}

function draw() {
  background(0);
  var factor=2;
  translate(width/2,height/2);
  stroke(255);
  noFill();
  circle(0,0,r*2);
  var i;
  for(i=0;i<total;i++)
  {
    PVector v=getVector(i);
    fill(255);
    circle(v.x,v.y,16);
  }
  for(i=0;i<total;i++)
  {
    PVector a=getVector(i);
    PVector b=getVector(i*factor);
    line(a.x, a.y, b.x, b.y);
  }
}
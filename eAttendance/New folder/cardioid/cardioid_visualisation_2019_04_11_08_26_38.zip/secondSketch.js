var factor =parseFloat(0);
var r;
function setup() {
  createCanvas(400, 400);
  r=width/2-16;
}

PVector getVector(int index,float total)
{
  var angle=parseFloat(map(index % total,0,total,0,TWO_PI));
  PVector v=PVector.fromAngle(angle+ PI);
  v.mult(r);
  return v;
}

function draw() {
  background(0);
  var total=parseInt(200);//int(map(mouseX,0,width,0,200));
  factor+=0.01;
  translate(width/2,height/2);
  stroke(255);
  noFill();
  circle(0,0,r*2);
  var i=parseInt(0);
  for(i=0;i<total;i++)
  {
    PVector v=getVector(i,total);
    fill(255);
    circle(v.x,v.y,16);
  }
  for(i=0;i<total;i++)
  {
    PVector a=getVector(i,total);
    PVector b=getVector(i*factor,total);
    line(a.x, a.y, b.x, b.y);
  }
}